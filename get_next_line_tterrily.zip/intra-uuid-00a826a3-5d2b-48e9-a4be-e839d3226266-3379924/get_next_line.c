/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tterrily <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/20 22:57:02 by tterrily          #+#    #+#             */
/*   Updated: 2020/12/03 18:20:17 by tterrily         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

static char		*ft_line(char *h_v, char **line)
{
	char		*t;
	char		*tmp;

	tmp = h_v;
	if ((t = f_chr(h_v, '\n')))
	{
		if (*h_v == ('\n'))
		{
			*line = f_join("", NULL);
			h_v = f_join((t + 1), NULL);
		}
		else
		{
			*t = '\0';
			*line = f_join(h_v, NULL);
			h_v = f_join((t + 1), NULL);
		}
	}
	else
	{
		*line = f_join(h_v, NULL);
		h_v = NULL;
	}
	free(tmp);
	return (h_v);
}

int				get_next_line(int fd, char **line)
{
	char		*buf;
	static char	*hv;
	char		*tmp;
	int			rd;

	if (!(buf = (char *)malloc(sizeof(char) * (BUFFER_SIZE + 1))))
		return (-1);
	if (fd <= 0 || !line || read(fd, buf, 0) < 0 || BUFFER_SIZE <= 0)
		return (-1);
	while (!(f_chr(hv, '\n')) && (rd = read(fd, buf, BUFFER_SIZE)) > 0)
	{
		*(buf + rd) = '\0';
		tmp = hv;
		hv = f_join(hv, buf);
		free(tmp);
	}
	free(buf);
	if ((!rd) && (!ft_strlen(hv)) && (*line = f_join("", NULL)))
		return (0);
	hv = ft_line(hv, line);
	return (rd == 0 && !hv ? 0 : 1);
}
