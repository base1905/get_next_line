/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tterrily <tterrily@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/24 15:47:53 by tterrily          #+#    #+#             */
/*   Updated: 2020/12/02 21:52:58 by tterrily         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H
# include <unistd.h>
# include <stdlib.h>

int				get_next_line(int fd, char **l);

size_t			ft_strlen(char *s);

char			*f_chr(char *s, int c);

char			*f_join(char *l, char *ll);

#endif
