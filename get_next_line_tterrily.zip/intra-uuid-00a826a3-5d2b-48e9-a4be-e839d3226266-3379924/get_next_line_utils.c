/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tterrily <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/24 15:50:58 by tterrily          #+#    #+#             */
/*   Updated: 2020/12/03 19:22:01 by tterrily         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

size_t		ft_strlen(char *s)
{
	if (!s)
		return (0);
	return ((s && *s != '\0') ? 1 + ft_strlen(++s) : 0);
}

char		*f_join(char *l, char *ll)
{
	char	*ret;
	char	*tmp;
	size_t	len_ret;

	if (!l && !ll)
		return (NULL);
	len_ret = ft_strlen(l) + ft_strlen(ll) + 1;
	tmp = (char *)malloc(sizeof(char) * (len_ret));
	if (!tmp)
		return (NULL);
	ret = tmp;
	while (l && *l != '\0')
		*tmp++ = *l++;
	while (ll && *ll != '\0')
		*tmp++ = *ll++;
	*tmp = '\0';
	return (ret);
}

char		*f_chr(char *s, int c)
{
	if (!s)
		return (NULL);
	while (s && *s != c && *s != '\0')
		s++;
	if (!c)
		return ((char *)s);
	return (*(s) == (char)c ? (char *)s : NULL);
}
